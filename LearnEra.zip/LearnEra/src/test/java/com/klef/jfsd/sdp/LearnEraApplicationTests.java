package com.klef.jfsd.sdp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnEraApplicationTests {

	@Test
	void contextLoads() {
	}

}
