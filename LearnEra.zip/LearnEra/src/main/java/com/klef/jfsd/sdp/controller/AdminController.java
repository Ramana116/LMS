package com.klef.jfsd.sdp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.sdp.model.Admin;
import com.klef.jfsd.sdp.service.AdminService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class AdminController {
  
  @Autowired
  private AdminService adminService;
  
  @GetMapping("/")
  public ModelAndView home()
  {
    ModelAndView mv=new ModelAndView("index");
    return mv;
  }
  
  @GetMapping("adminhome")
  public ModelAndView adminhome()
  {
    ModelAndView mv=new ModelAndView("admin-dashboard");
    return mv;
  }
  
  @GetMapping("adminlogin")
  public ModelAndView adminlogin() 
  {
    ModelAndView mv=new ModelAndView();
    mv.setViewName("admin-login");
    return mv;
  }
  
  @PostMapping("checkAdminLogin")
  //@ResponseBody
  public ModelAndView checkAdminLogin(HttpServletRequest request) 
  {
	   ModelAndView mv = new ModelAndView();
	   String auname=request.getParameter("auname"); 
	   String apassword= request.getParameter("apwd"); 
	   Admin admin= adminService.checkAdminLogin(auname, apassword); 

    if(admin!=null) {
      //return "admin login success";
      mv.setViewName("admin-dashboard");
    }
    else {
      //return "admin login fail";
      mv.setViewName("adminloginfail");
      mv.addObject("message","Login Failed!");
    }
    return mv;
  }
  
  

}