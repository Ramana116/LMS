package com.klef.jfsd.sdp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.sdp.model.Instructor;
import com.klef.jfsd.sdp.model.Student;
import com.klef.jfsd.sdp.service.InstructorService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class InstructorController
{
	@Autowired
	private InstructorService instructorService;

	 @GetMapping("instructorhome")
	  public ModelAndView instructorhome()
	  {
	    ModelAndView mv=new ModelAndView("instructor-dashboard");
	    return mv;
	  }
	 
	 @GetMapping("instructorreg")
	   public ModelAndView instructorreg()
	   {
		   ModelAndView mv=new ModelAndView();
		   mv.setViewName("instructor-register");
		   return mv;
	   }
	  
	  @PostMapping("insertinstructor")
	   public ModelAndView insertinstructor(HttpServletRequest request)
	   {
	    String name = request.getParameter("iname");
	    String gender = request.getParameter("igender");
	    String email = request.getParameter("iemail");
	    String password = request.getParameter("ipwd");
	    String contact = request.getParameter("icontact");
	    String qualification = request.getParameter("iqualification");
	    String status = "Registered";
	    
	      Instructor instructor = new Instructor();
	      instructor.setName(name);
	      instructor.setGender(gender);
	      instructor.setEmail(email);
	      instructor.setPassword(password);
	      instructor.setContact(contact);
	      instructor.setQualification(qualification);
	      instructor.setStatus(status);
	      
	      String msg = instructorService.instructorRegistraion(instructor);

	      ModelAndView mv = new ModelAndView("instructor-login");
	      return mv;

	   }
	  
	  @GetMapping("instructorlogin")
	  public ModelAndView instructorlogin() {
	    ModelAndView mv=new ModelAndView();
	    mv.setViewName("instructor-login");
	    return mv;
	  }
	  
	  @PostMapping("checkInstructorLogin")
	  //@ResponseBody
	  public ModelAndView checkInstructorLogin(HttpServletRequest request) 
	  {
		   ModelAndView mv = new ModelAndView();
		   String iemail=request.getParameter("iemail"); 
		   String ipassword= request.getParameter("ipwd"); 
		   Instructor i= instructorService.checkInstructorLogin(iemail, ipassword); 

	    if(i!=null) {
	      mv.setViewName("instructor-dashboard");
	    }
	    else {
	     mv.setViewName("instructorloginfail");
	    }
	    return mv;
	  }  
	  
}
