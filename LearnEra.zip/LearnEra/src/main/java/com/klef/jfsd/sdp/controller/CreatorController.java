package com.klef.jfsd.sdp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.sdp.model.ContentCreator;
import com.klef.jfsd.sdp.model.Instructor;
import com.klef.jfsd.sdp.model.Student;
import com.klef.jfsd.sdp.service.CreatorService;
import com.klef.jfsd.sdp.service.InstructorService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class CreatorController
{
	@Autowired
	private CreatorService creatorService;

	 @GetMapping("cchome")
	  public ModelAndView cchome()
	  {
	    ModelAndView mv=new ModelAndView("cc-dashboard");
	    return mv;
	  }
	 
	 @GetMapping("ccreg")
	   public ModelAndView ccreg()
	   {
		   ModelAndView mv=new ModelAndView();
		   mv.setViewName("cc-register");
		   return mv;
	   }
	  
	  @PostMapping("insertcc")
	   public ModelAndView insertinstructor(HttpServletRequest request)
	   {
	    String name = request.getParameter("cname");
	    String gender = request.getParameter("cgender");
	    String email = request.getParameter("cemail");
	    String password = request.getParameter("cpwd");
	    String contact = request.getParameter("ccontact");
	    String qualification = request.getParameter("cqualification");
	    String status = "Registered";
	    
	      ContentCreator c = new ContentCreator();
	      c.setName(name);
	      c.setGender(gender);
	      c.setEmail(email);
	      c.setPassword(password);
	      c.setContact(contact);
	      c.setQualification(qualification);
	      c.setStatus(status);
	      
	      String msg = creatorService.CCRegistraion(c);

	      ModelAndView mv = new ModelAndView("cc-login");
	      return mv;

	   }
	  
	  @GetMapping("cclogin")
	  public ModelAndView cclogin() {
	    ModelAndView mv=new ModelAndView();
	    mv.setViewName("cc-login");
	    return mv;
	  }
	  
	  @PostMapping("checkCCLogin")
	  //@ResponseBody
	  public ModelAndView checkCCLogin(HttpServletRequest request) 
	  {
		   ModelAndView mv = new ModelAndView();
		   String cemail=request.getParameter("cemail"); 
		   String cpassword= request.getParameter("cpwd"); 
		   ContentCreator c = creatorService.checkCCLogin(cemail, cpassword); 

	    if(c!=null) {
	      mv.setViewName("cc-dashboard");
	    }
	    else {
	     mv.setViewName("ccloginfail");
	    }
	    return mv;
	  }
	  
	  
	  
}
