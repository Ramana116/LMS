package com.klef.jfsd.sdp.service;

import org.springframework.stereotype.Service;

import com.klef.jfsd.sdp.model.Student;

public interface StudentService
{

	public String studentRegistraion(Student s);
	public Student checkStudentLogin(String email,String password);
}
