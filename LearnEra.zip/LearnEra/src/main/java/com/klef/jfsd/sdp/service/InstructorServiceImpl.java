package com.klef.jfsd.sdp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.Repository;
import org.springframework.stereotype.Service;

import com.klef.jfsd.sdp.model.Instructor;
import com.klef.jfsd.sdp.repository.InstructorRepository;

@Service
public class InstructorServiceImpl implements InstructorService
{
	@Autowired
	private InstructorRepository instructorrepository;
	
	@Override
	public String instructorRegistraion(Instructor i)
	{
		instructorrepository.save(i);
		return "Instructor Registration Successfull" ;
	}

	@Override
	public Instructor checkInstructorLogin(String email, String password) 
	{
		return instructorrepository.checkInstructorLogin(email, password);
		
	}

}
