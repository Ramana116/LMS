package com.klef.jfsd.sdp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.sdp.model.Admin;
import com.klef.jfsd.sdp.model.Instructor;
import com.klef.jfsd.sdp.model.Student;
import com.klef.jfsd.sdp.service.StudentService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class StudentController 
{
	
	@Autowired
	private StudentService studentService;
	
	
	 @GetMapping("studenthome")
	  public ModelAndView studenthome()
	  {
	    ModelAndView mv=new ModelAndView("student-dashboard");
	    return mv;
	  }
	 
	 @GetMapping("studentreg")
	   public ModelAndView studentreg()
	   {
		   ModelAndView mv=new ModelAndView();
		   mv.setViewName("student-register");
		   return mv;
	   }
	  
	  @PostMapping("insertstudent")
	   public ModelAndView insertstudent(HttpServletRequest request)
	   {
	    String name = request.getParameter("sname");
	    String gender = request.getParameter("sgender");
	    String dob = request.getParameter("sdob");
	    String email = request.getParameter("semail");
	    String password = request.getParameter("spwd");
	    String contact = request.getParameter("scontact");
	    String status = "Registered";
	    
	      Student student = new Student();
	      student.setName(name);
	      student.setGender(gender);
	      student.setDateofbirth(dob);
	      student.setEmail(email);
	      student.setPassword(password);
	      student.setContact(contact);
	      student.setStatus(status);
	      
	      String msg = studentService.studentRegistraion(student);

	      ModelAndView mv = new ModelAndView("student-login");
	      mv.addObject("message", msg);
	    
	      return mv;

	   }
	  
	  @GetMapping("studentlogin")
	  public ModelAndView studentlogin() {
	    ModelAndView mv=new ModelAndView();
	    mv.setViewName("student-login");
	    return mv;
	  }
	  
	  @PostMapping("checkStudentLogin")
	  //@ResponseBody
	  public ModelAndView checkStudentLogin(HttpServletRequest request) 
	  {
		   ModelAndView mv = new ModelAndView();
		   String semail=request.getParameter("semail"); 
		   String spassword= request.getParameter("spwd"); 
		   Student s= studentService.checkStudentLogin(semail, spassword); 

	    if(s!=null) {
	      mv.setViewName("student-dashboard");
	    }
	    else {
	     mv.setViewName("studentloginfail");
	      mv.addObject("message","Login Failed!");
	    }
	    return mv;
	  }
	  
	  
	
}
