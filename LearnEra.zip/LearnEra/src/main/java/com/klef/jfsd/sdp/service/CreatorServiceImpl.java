package com.klef.jfsd.sdp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.Repository;
import org.springframework.stereotype.Service;

import com.klef.jfsd.sdp.model.ContentCreator;
import com.klef.jfsd.sdp.repository.CreatorRepository;

@Service
public class CreatorServiceImpl implements CreatorService
{
	@Autowired
	private CreatorRepository creatorrepository;
	
	@Override
	public String CCRegistraion(ContentCreator c)
	{
		creatorrepository.save(c);
		return "Content Creator Registration Successfull" ;
	}

	@Override
	public ContentCreator checkCCLogin(String email, String password) 
	{
		return creatorrepository.checkCCLogin(email, password);
		
	}
}