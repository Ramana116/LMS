package com.klef.jfsd.sdp.service;

import com.klef.jfsd.sdp.model.ContentCreator;

public interface CreatorService 
{
	public String CCRegistraion(ContentCreator c);
	public ContentCreator checkCCLogin(String email,String password);
}
