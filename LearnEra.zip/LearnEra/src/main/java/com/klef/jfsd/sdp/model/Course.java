package com.klef.jfsd.sdp.model;

import java.sql.Blob;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="course_table")
public class Course
{
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int courseid;
  @Column(name = "ctitle",length = 50,unique = true,nullable = false)
  private String coursetitle;
  @Column(name = "cdescription",length = 50,unique = true,nullable = false)
  private String coursedescription;
  @Column(name="cimage",nullable = false)
  private Blob image;
}
